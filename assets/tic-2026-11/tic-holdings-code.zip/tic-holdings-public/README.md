# TIC holdings public code snapshot

Prepared 1 November 2026 from research package commit 9eeb651. No private notes, repository history or raw source PDFs/HTML are included. Nicholas framed the question and scope; the code was developed with AI assistance. Public metadata adjustment: the 2024 survey_date is ISO 2024-06-28; numerical values are unchanged. See docs/methods.md.

## Rebuild from the included extracted tables

Use Python 3.13.4. From this directory:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/build.py
python scripts/charts.py
```

This regenerates the two analytical CSV files and charts. It does not itself verify the original PDFs or execute all validation checks. The exact versions were tested; another pypdf version failed extraction.

## Re-extract the PDFs and run the original full checks

The source PDFs, historical data and HTML snapshots are not bundled. `sources/SOURCES.md` gives their public URLs; `sources/MANIFEST.json` records the original hashes. To attempt retrieval at their expected paths, run:

```sh
python scripts/fetch_sources.py
python scripts/extract.py
python scripts/build.py
python scripts/validate.py
python scripts/charts.py
```

The retrieval helper stops if any source cannot be fetched or no longer matches the archived hash. HTML and the historical data file may have changed since retrieval. If a hash differs, the original full validation cannot be reproduced from that current file; do not relabel a changed vintage as the archived one. The included extracted tables and saved validation results remain inspectable. Network retrieval availability is not guaranteed. The original full pipeline was independently rerun by an AI reviewer against the preserved source files before publication.

`outputs/validation.md` and `.json` are the saved source-package results. The 2024 ISO date correction affects metadata only and none of those arithmetic checks. Chart SVGs may vary in generated IDs between runs.

## Files and scope

All files included here are enumerated in PUBLIC_FILES.txt. SHA256SUMS.json records their hashes. The package is a descriptive record of foreign Treasury holdings, not a causal test, demand-elasticity estimate or trading recommendation.
