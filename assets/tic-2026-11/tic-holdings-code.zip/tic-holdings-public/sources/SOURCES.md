# Source inventory

All files retrieved by Nicholas Beroud's research session on 1 November 2026 (evening, New York time; 2026-11-01T23:30Z to 2026-11-02T00:40Z) with `curl` from the URLs below. SHA-256 hashes and byte sizes are in `MANIFEST.json`; `scripts/validate.py` (check V0) confirms the files are unchanged.

All amounts in the survey reports are **market values**, in **billions of US dollars** unless noted, as of the **end-June survey date** of each year.

## Survey reports (Department of the Treasury, Federal Reserve Bank of New York, Board of Governors of the Federal Reserve System)

| File | Report | Observation date(s) used | Published | Tables used | PDF page (printed page) | Units |
|---|---|---|---|---|---|---|
| `shl/shl2025r.pdf` | Foreign Portfolio Holdings of U.S. Securities as of June 30, 2025 | end-June 2008 to 2025 (18 columns) | April 2026 (data release dated April 30, 2026) | Exhibit 7: U.S. Long-Term Securities by Foreign Holder Sector (Treasury debt block) | 20 (19) | $bn |
| | | | | Exhibit 8: U.S. Short-Term Securities by Foreign Holder Sector (Treasury debt block) | 22 (21) | $bn |
| | | | | Exhibit 2: Foreign Holdings of U.S. Securities by Type (Treasury debt block: total outstanding, foreign-owned) | 10 (9) | $bn |
| | | | | Table 1: Accounting for Changes in Foreign Holdings of U.S. Long-Term Securities (cited in the notes, not in the dataset) | 8 (7) | $trillion |
| | | | | Sections 4.2.1 to 4.3.4: data analysis and editing, SHL vs SLT, adjustments, repo and securities lending, survey history, country of residence | 48 to 55 (47 to 54) | text |
| `shl/shl2024r.pdf` | Foreign Portfolio Holdings of U.S. Securities as of June 28, 2024 | end-June 2007 to 2024 | April 2025 | Table 8 (long-term) and Table 9 (short-term) by Foreign Holder Sector | 20, 22 | $bn |
| `shl/shla2016r.pdf` | Foreign Portfolio Holdings of U.S. Securities as of June 30, 2016 | end-June 2006 to 2016 | April 2017 | Appendix Exhibit 10 (long-term held by foreign official institutions) and Exhibit 11 (short-term) | 151 (C-7), 152 (C-8) | $bn; shares rounded to whole percent |
| `shl/shla2008r.pdf` | Report on Foreign Portfolio Holdings of U.S. Securities as of June 30, 2008 | March 2000; end-June 2002 to 2008 (long-term), 2005 to 2008 (short-term) | April 2009 | Table 7 (long-term held by foreign official institutions) and Table 8 (short-term) | 15, 16 | $bn |

URLs (all under `https://ticdata.treasury.gov/resource-center/data-chart-center/tic/Documents/`): `shl2025r.pdf`, `shl2024r.pdf`, `shla2016r.pdf`, `shla2008r.pdf`. Listing page: https://home.treasury.gov/data/treasury-international-capital-tic-system/us-liabilities-to-foreigners-from-holdings-of-us-securities

## Historical data file

| File | Content | Release | Used for |
|---|---|---|---|
| `shl/shlhistdat.txt` (and the same release as `shlhistdat.html`) | Foreign holdings of U.S. securities by country and security type, all survey dates since 1974 (December 1974 to June 2025), **millions of dollars**, no official/private split | "For release April 30, 2026" | Check V3: the "Total" row for long-term and short-term Treasury debt, 2008 to 2025 |

URL: `https://ticdata.treasury.gov/resource-center/data-chart-center/tic/Documents/shlhistdat.txt`

## Reference pages (HTML snapshots)

| File | Page | URL | Used for |
|---|---|---|---|
| `web/tic-country-codes-official-institutions.html` | TIC Country Codes and Partial List of Foreign Official Institutions | https://home.treasury.gov/tic-country-codes-and-partial-list-of-foreign-official-institutions | Definition of foreign official institutions (section B2) |
| `web/tic-faq2.html` | Frequently Asked Questions Regarding the TIC System and TIC Data, page 2 | https://home.treasury.gov/data/treasury-international-capital-tic-system-home-page/frequently-asked-questions-regarding/ticfaq2 | FAQ 10a: TIC official holdings versus FRBNY custody holdings; SLT and monthly data |
| `web/tic-system.html` | Treasury International Capital (TIC) System | https://home.treasury.gov/data/treasury-international-capital-tic-system | Entry point |

## Not used, and why

- **Monthly "Major Foreign Holders of U.S. Treasury Securities" (MFH) and SLT tables.** Different instrument and valuation basis (estimated values, bills at face value). Out of scope for this bounded annual exercise; see `docs/comparability.md`.
- **Survey appendices** (`shl_appendix_2025.zip` and others): country-level detail is not needed for the aggregate official/private question.
- **Reports for other years.** The 2025 report already provides a consistent 2008 to 2025 series. Three earlier vintages (2008, 2016, 2024) were downloaded only to test for revisions.
