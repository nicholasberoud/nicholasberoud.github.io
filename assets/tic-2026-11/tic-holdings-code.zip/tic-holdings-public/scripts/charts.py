"""Two charts in the site's dark theme, newsroom layout: legend row on top with short
slanted colour marks, value axis on the right with the unit on the top label only,
horizontal gridlines, a stronger reference line, direct callouts with thin leader lines.
Titles, subtitles and sources live in the web page, not in the image.
Chart data is written next to each image.

Run: python3 scripts/charts.py
"""
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "charts"
OUT.mkdir(parents=True, exist_ok=True)

BG, GRID, TICK, LABEL, REF = "#0d1117", "#21262d", "#89929b", "#c6cdd5", "#c6cdd5"
BLUE, ORANGE, GREEN = "#77bdfb", "#faa356", "#7ce38b"

plt.rcParams.update({
    "figure.facecolor": BG, "axes.facecolor": BG, "savefig.facecolor": BG,
    "axes.edgecolor": GRID, "axes.labelcolor": TICK, "xtick.color": TICK, "ytick.color": TICK,
    "font.size": 11, "font.family": "DejaVu Sans", "svg.fonttype": "none",
})

with (ROOT / "data" / "treasury_official_private.csv").open() as f:
    data = list(csv.DictReader(f))


def series(mat, key):
    rows = [r for r in data if r["maturity"] == mat]
    return [int(r["year"]) for r in rows], [float(r[key]) for r in rows]


def newsroom(ax, yticks, unit, xticks):
    """Right-hand value axis, unit on the top label, horizontal grid, no box."""
    for s in ("top", "left", "right"):
        ax.spines[s].set_visible(False)
    ax.spines["bottom"].set_color(TICK)
    ax.yaxis.tick_right()
    ax.set_yticks(yticks)
    ax.set_yticklabels([f"{t:,.0f}{unit}" if t == yticks[-1] else f"{t:,.0f}" for t in yticks])
    ax.tick_params(axis="y", length=0, pad=6)
    ax.tick_params(axis="x", length=4, color=TICK)
    ax.set_xticks(xticks)
    ax.grid(axis="y", color=GRID, linewidth=0.9)
    ax.set_axisbelow(True)
    for t in ax.get_xticklabels() + ax.get_yticklabels():
        t.set_fontfamily("DejaVu Sans Mono")


def legend_row(fig, items):
    """Legend across the top, newsroom style: short slanted colour marks."""
    handles = [Line2D([0], [0], color=c, lw=0, marker=(2, 0, -35), markersize=11, markeredgewidth=2.6) for _, c in items]
    fig.legend(handles, [l for l, _ in items], loc="upper left", bbox_to_anchor=(0.02, 1.0), ncol=len(items),
               frameon=False, handlelength=0.9, handletextpad=0.5, columnspacing=1.4, labelcolor=LABEL, fontsize=11)


def callout(ax, x, y, text, tx, ty, ha="left"):
    ax.plot([x], [y], "o", color=LABEL, markersize=5, zorder=5)
    ax.annotate(text, xy=(x, y), xytext=(tx, ty), color=LABEL, fontsize=10, ha=ha, va="center",
                arrowprops=dict(arrowstyle="-", color=TICK, lw=0.8, shrinkA=2, shrinkB=4))


def save(fig, name, rows, header):
    for ext in ("png", "svg"):
        fig.savefig(OUT / f"{name}.{ext}", dpi=200 if ext == "png" else None)
    with (OUT / f"{name}.csv").open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)
    plt.close(fig)
    print(f"wrote outputs/charts/{name}.png/.svg/.csv")


XT = [2008, 2012, 2016, 2020, 2024]

# Chart 1: long-term Treasury holdings, official vs private, billions of dollars
yrs, off = series("long_term", "official_bn")
_, prv = series("long_term", "private_bn")
fig, ax = plt.subplots(figsize=(4.8, 3.9))
fig.subplots_adjust(top=0.86, left=0.04, right=0.80, bottom=0.10)
ax.plot(yrs, off, color=BLUE, linewidth=2.4)
ax.plot(yrs, prv, color=ORANGE, linewidth=2.4)
ax.set_ylim(0, 5000)
newsroom(ax, [0, 1000, 2000, 3000, 4000, 5000], "bn", XT)
ax.axhline(0, color=REF, linewidth=1.1)
legend_row(fig, [("Official", BLUE), ("Private", ORANGE)])
callout(ax, 2025, prv[-1], "2025: private\npasses official", 2019.9, 4720)
callout(ax, 2021, off[13], "Official peak, 2021", 2011.4, 4560)
save(fig, "tic-lt-official-private", [(y, o, p) for y, o, p in zip(yrs, off, prv)], ["year", "official_bn", "private_bn"])

# Chart 2: official share of foreign holdings, by maturity definition
fig, ax = plt.subplots(figsize=(4.8, 3.9))
fig.subplots_adjust(top=0.86, left=0.04, right=0.84, bottom=0.10)
lines = {}
for mat, col in (("long_term", BLUE), ("all", GREEN), ("short_term", ORANGE)):
    y, s = series(mat, "official_share_pct")
    ax.plot(y, s, color=col, linewidth=2.4)
    lines[mat] = (y, s)
ax.set_ylim(0, 100)
newsroom(ax, [0, 25, 50, 75, 100], "%", XT)
ax.axhline(50, color=REF, linewidth=1.1)
ax.text(2008.1, 44.5, "Half", color=TICK, fontsize=9.5)
legend_row(fig, [("Long-term", BLUE), ("All", GREEN), ("Bills", ORANGE)])
callout(ax, 2016, lines["short_term"][1][8], "Bills: private\nahead from 2016", 2010.2, 22)
callout(ax, 2025, lines["long_term"][1][-1], "Long-term: private\nahead in 2025", 2018.4, 88)
save(fig, "tic-official-share-by-maturity",
     [(r["year"], r["maturity"], r["official_share_pct"]) for r in data], ["year", "maturity", "official_share_pct"])
