"""Retrieve public source files; refuse changed vintages. Not run automatically."""
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen
ROOT = Path(__file__).resolve().parents[1]
URLS = {'sources/shl/shl2024r.pdf': 'https://ticdata.treasury.gov/resource-center/data-chart-center/tic/Documents/shl2024r.pdf', 'sources/shl/shl2025r.pdf': 'https://ticdata.treasury.gov/resource-center/data-chart-center/tic/Documents/shl2025r.pdf', 'sources/shl/shla2008r.pdf': 'https://ticdata.treasury.gov/resource-center/data-chart-center/tic/Documents/shla2008r.pdf', 'sources/shl/shla2016r.pdf': 'https://ticdata.treasury.gov/resource-center/data-chart-center/tic/Documents/shla2016r.pdf', 'sources/shl/shlhistdat.html': 'https://ticdata.treasury.gov/resource-center/data-chart-center/tic/Documents/shlhistdat.html', 'sources/shl/shlhistdat.txt': 'https://ticdata.treasury.gov/resource-center/data-chart-center/tic/Documents/shlhistdat.txt', 'sources/web/tic-country-codes-official-institutions.html': 'https://home.treasury.gov/tic-country-codes-and-partial-list-of-foreign-official-institutions', 'sources/web/tic-faq2.html': 'https://home.treasury.gov/data/treasury-international-capital-tic-system-home-page/frequently-asked-questions-regarding/ticfaq2', 'sources/web/tic-system.html': 'https://home.treasury.gov/data/treasury-international-capital-tic-system'}
manifest = json.loads((ROOT / "sources/MANIFEST.json").read_text())
for relative, url in URLS.items():
    expected = manifest[relative]["sha256"]
    target = ROOT / relative
    if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest() == expected:
        print("Already matches:", relative)
        continue
    with urlopen(Request(url, headers={"User-Agent": "TIC-public-reproduction/1.0"}), timeout=60) as response:
        data = response.read()
    if hashlib.sha256(data).hexdigest() != expected:
        raise SystemExit("Source changed; original vintage required: " + url)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    print("Verified:", relative)
