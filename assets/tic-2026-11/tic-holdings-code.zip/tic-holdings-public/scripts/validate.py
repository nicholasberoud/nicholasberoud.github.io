"""Validation checks for the TIC official/private dataset.

Hard checks (fail the run): accounting identities, published-share agreement,
agreement with Treasury's historical data file, and internal consistency of Exhibit 2.
Reported checks (never fail): revisions across report vintages, and the private-over-
official crossover year under each definition.

Writes outputs/validation.md and outputs/validation.json.
Run: python3 scripts/validate.py
"""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXT = ROOT / "data" / "extracts"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

results = []  # (id, description, passed or None for informational, detail)


def check(cid, desc, passed, detail):
    results.append(dict(id=cid, description=desc, passed=passed, detail=detail))


def read(path):
    with path.open() as f:
        return list(csv.DictReader(f))


def f(x):
    return float(x) if x not in ("", None) else None


# V0: preserved source files are unchanged since retrieval
import hashlib
manifest = json.loads((ROOT / "sources" / "MANIFEST.json").read_text())
changed = [p for p, m in manifest.items() if hashlib.sha256((ROOT / p).read_bytes()).hexdigest() != m["sha256"]]
check("V0", "Preserved source files match sources/MANIFEST.json (sha256)", not changed,
      f"{len(manifest)} files verified" if not changed else f"changed: {changed}")

data = read(ROOT / "data" / "treasury_official_private.csv")
v25 = {(int(r["year"]), r["maturity"]): r for r in read(EXT / "vintage_2025.csv")}

# V1: official + private = total (published billions, so allow 1bn rounding)
bad = [(y, m, f(r["total_foreign"]) - f(r["official"]) - f(r["private"]))
       for (y, m), r in v25.items() if abs(f(r["total_foreign"]) - f(r["official"]) - f(r["private"])) > 1.0]
check("V1", "Official + private = total foreign, long- and short-term, 2008-2025 (tolerance 1bn)", not bad,
      "all 36 rows within rounding" if not bad else f"exceptions: {bad}")

# V2: share computed from levels vs share as published (tolerance 0.15 pp: the report computes
# shares from unrounded amounts, we compute from rounded billions)
diffs = [(int(r["year"]), r["maturity"], round(f(r["official_share_pct"]) - f(r["official_share_published_pct"]), 2))
         for r in data if r["maturity"] != "all"]
worst = max(diffs, key=lambda d: abs(d[2]))
check("V2", "Computed official share matches the published percentage (tolerance 0.15 pp)",
      abs(worst[2]) <= 0.15, f"largest gap {worst[2]} pp ({worst[0]}, {worst[1]})")

# V3: Treasury's historical data file (shlhistdat.txt, release of April 30, 2026), 'Total' row
rows = [l.rstrip("\r\n").split("\t") for l in open(ROOT / "sources" / "shl" / "shlhistdat.txt", encoding="latin-1")]
dates, heads = rows[8], rows[10]
total = next(r for r in rows if r[:2] == ["99996", "Total"])
hist = {}
for j, (d, h) in enumerate(zip(dates, heads)):
    if d.startswith("Jun-") and h.strip().lower() == "treasury debt":
        yr = 2000 + int(d[4:])
        hist.setdefault(yr, []).append(float(total[j]) / 1000)  # millions -> billions; LT first, ST second
mism = []
for yr in range(2008, 2026):
    lt, st = hist[yr][0], hist[yr][1]
    for mat, val in (("long_term", lt), ("short_term", st)):
        if abs(val - f(v25[(yr, mat)]["total_foreign"])) > 1.0:
            mism.append((yr, mat, round(val, 1), v25[(yr, mat)]["total_foreign"]))
check("V3", "Total foreign Treasury holdings match Treasury's historical data file (shlhistdat.txt), 2008-2025, tolerance 1bn",
      not mism, "all 36 long- and short-term totals agree" if not mism else f"mismatches: {mism}")

# V4: Exhibit 2 foreign-owned Treasury debt = long-term + short-term totals
ex2 = read(EXT / "exhibit2_2025_outstanding.csv")
gap = [(int(r["year"]), round(f(r["foreign_owned"]) - f(v25[(int(r["year"]), "long_term")]["total_foreign"])
                                - f(v25[(int(r["year"]), "short_term")]["total_foreign"]), 1)) for r in ex2]
badgap = [g for g in gap if abs(g[1]) > 1.5]
check("V4", "Exhibit 2 foreign-owned Treasury debt equals Exhibit 7 + Exhibit 8 totals (tolerance 1.5bn)",
      not badgap, "all 18 years agree" if not badgap else f"gaps: {badgap}")

# V5-V7: revisions across report vintages (informational)
def compare(vintage_file, label, pct_tol):
    old = read(EXT / vintage_file)
    out = []
    for r in old:
        y, m = int(r["year"]), r["maturity"]
        if (y, m) not in v25:
            continue
        new = v25[(y, m)]
        for k in ("total_foreign", "official", "private"):
            if r[k] != "" and abs(f(r[k]) - f(new[k])) > 0.5:
                out.append(f"{y} {m} {k}: {r[k]} -> {new[k]}")
        if abs(f(r["pct_official_published"]) - f(new["pct_official_published"])) > pct_tol:
            out.append(f"{y} {m} share: {r['pct_official_published']} -> {new['pct_official_published']}")
    n = sum(1 for r in old if (int(r["year"]), r["maturity"]) in v25)
    check(label, f"Revisions: {vintage_file.replace('.csv','')} report vs 2025 report, overlapping Treasury rows",
          None, f"{n} overlapping rows; " + ("no revisions" if not out else "revised: " + "; ".join(out)))


compare("vintage_2024.csv", "V5", 0.05)
compare("vintage_2016.csv", "V6", 0.5)   # 2016 report rounds shares to whole percent
compare("vintage_2008.csv", "V7", 0.05)

# V8: crossover, same definition throughout (informational)
cross = {}
for mat in ("long_term", "short_term", "all"):
    seq = [(int(r["year"]), f(r["private_bn"]), f(r["official_bn"])) for r in data if r["maturity"] == mat]
    first = next((y for y, p, o in seq if p > o), None)
    stays = first is not None and all(p > o for y, p, o in seq if y >= first)
    near = [(y, round(p - o, 1)) for y, p, o in seq if abs(p - o) < 25]
    cross[mat] = dict(first_year_private_exceeds_official=first, private_above_in_every_later_year=stays, near_ties_under_25bn=near)
check("V8", "First survey year in which private holdings exceed official holdings, by definition", None,
      "; ".join(f"{m}: {c['first_year_private_exceeds_official']} (stays above: {c['private_above_in_every_later_year']}; near ties: {c['near_ties_under_25bn']})"
                for m, c in cross.items()))

# Write reports
(OUT / "validation.json").write_text(json.dumps(dict(checks=results, crossover=cross), indent=1))
lines = ["# Validation results", "", "Generated by `scripts/validate.py`.", "",
         "| Check | Description | Result | Detail |", "|---|---|---|---|"]
for r in results:
    res = "info" if r["passed"] is None else ("PASS" if r["passed"] else "FAIL")
    lines.append(f"| {r['id']} | {r['description']} | {res} | {r['detail']} |")
(OUT / "validation.md").write_text("\n".join(lines) + "\n")
print("\n".join(lines))
sys.exit(0 if all(r["passed"] is not False for r in results) else 1)
