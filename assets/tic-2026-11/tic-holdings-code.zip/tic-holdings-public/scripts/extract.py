"""Extract foreign official / private holdings of U.S. Treasury securities from the
annual survey reports (Foreign Portfolio Holdings of U.S. Securities).

Reads the preserved PDFs in sources/shl/, writes one verbatim extract per source
table to data/extracts/. Numbers are copied as published (billions of dollars,
percent to one decimal where the report gives one). Nothing is computed here.

Run: python3 scripts/extract.py
"""
import csv
import re
from pathlib import Path

from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "sources" / "shl"
OUT = ROOT / "data" / "extracts"
OUT.mkdir(parents=True, exist_ok=True)

NUM = re.compile(r"-?[\d,]+(?:\.\d+)?")


def page_text(pdf, page_no):
    """Text of one PDF page (1-based)."""
    return norm(PdfReader(str(SRC / pdf)).pages[page_no - 1].extract_text())


def norm(text):
    """Normalise PDF text: non-breaking spaces and Unicode hyphens become ASCII."""
    return (text or "").replace("\xa0", " ").replace("\u2010", "-")


def nums(line):
    return [float(x.replace(",", "")) for x in NUM.findall(line)]


def find_page(pdf, anchor, start=1):
    reader = PdfReader(str(SRC / pdf))
    for i in range(start - 1, len(reader.pages)):
        if anchor in norm(reader.pages[i].extract_text()):
            return i + 1
    raise ValueError(f"{anchor!r} not found in {pdf}")


def block_after(lines, header, labels):
    """Return {label: numbers} for the rows that follow an exact header line."""
    i = next(k for k, l in enumerate(lines) if l.strip() == header)
    out = {}
    for l in lines[i + 1 : i + 1 + len(labels)]:
        for lab in labels:
            if l.startswith(lab):
                out[lab] = nums(l[len(lab):])
    assert set(out) == set(labels), (header, out.keys())
    return out


def write(name, rows):
    path = OUT / name
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {path.relative_to(ROOT)} ({len(rows)} rows)")


def recent_format(pdf, vintage, lt_anchor, st_anchor):
    """2024 and 2025 reports: holder-sector tables with a Treasury debt block."""
    rows = []
    for maturity, anchor in (("long_term", lt_anchor), ("short_term", st_anchor)):
        pg = find_page(pdf, anchor, start=10)
        lines = page_text(pdf, pg).splitlines()
        years = [int(y) for y in re.findall(r"\b(20\d\d)\b", next(l for l in lines if re.match(r"^20\d\d 20\d\d", l)))]
        blk = block_after(lines, "Treasury debt", ["Total foreign", "Official", "Private", "Percent official"])
        for k, y in enumerate(years):
            rows.append(dict(vintage=vintage, source_file=pdf, pdf_page=pg, table=anchor, maturity=maturity, year=y,
                             total_foreign=blk["Total foreign"][k], official=blk["Official"][k],
                             private=blk["Private"][k], pct_official_published=blk["Percent official"][k]))
    return rows


def v2016():
    pdf = "shla2016r.pdf"
    rows = []
    pg = find_page(pdf, "Exhibit 10: Value of long-term securities held by foreign official", start=100)
    lines = page_text(pdf, pg).splitlines()
    years = [int(y) for y in re.findall(r"Jun(20\d\d)", next(l for l in lines if l.startswith("Jun2006")))]
    tot = nums(next(l for l in lines if l.startswith("Total foreign holdings Treasury debt")))
    i = next(k for k, l in enumerate(lines) if l.startswith("Total foreign holdings Treasury debt"))
    off = nums(lines[i + 1].replace("Of which: Foreign official", ""))
    pct = nums(lines[i + 2].replace("Percent foreign official", ""))
    for k, y in enumerate(years):
        rows.append(dict(vintage=2016, source_file=pdf, pdf_page=pg, table="Exhibit 10", maturity="long_term", year=y,
                         total_foreign=tot[k], official=off[k], private="", pct_official_published=pct[k]))
    pg = find_page(pdf, "Exhibit 11: Value of short-term securities held by foreign official", start=100)
    for l in page_text(pdf, pg).splitlines():
        if re.match(r"^20\d\d ", l):
            v = nums(l)
            # columns: year, total official, total share, total, total private,
            # Treasury official, Treasury share, Treasury total, Treasury private, ...
            rows.append(dict(vintage=2016, source_file=pdf, pdf_page=pg, table="Exhibit 11", maturity="short_term",
                             year=int(v[0]), total_foreign=v[7], official=v[5], private=v[8], pct_official_published=v[6]))
    return rows


def v2008():
    pdf = "shla2008r.pdf"
    rows = []
    reader = PdfReader(str(SRC / pdf))
    for maturity, anchor, tot_lab in (
        ("long_term", "Table 7.  Value of long-term securities held by foreign official", "Total foreign holdings, U.S. Treasury"),
        ("short_term", "Table 8.  Value of short-term securities held by foreign official", "Total foreign holdings, short-term U.S. Treasury debt"),
    ):
        pg = next(i + 1 for i, p in enumerate(reader.pages) if i > 8 and anchor in norm(p.extract_text()))
        text = norm(reader.pages[pg - 1].extract_text())
        if maturity == "long_term":
            text = text.replace("U.S. Treasury \ndebt", "U.S. Treasury debt")
        lines = text.splitlines()
        i = next(k for k, l in enumerate(lines) if l.startswith(tot_lab))
        head = next(l for l in lines[:i] if l.startswith("Type of Security"))
        years = [int(y) for y in re.findall(r"(20\d\d)", head)]
        tot = nums(lines[i][len(tot_lab):])
        off = nums(lines[i + 1].replace("of which:  foreign official holdings", ""))
        pct = nums(lines[i + 2].replace("Percent foreign official", ""))
        for k, y in enumerate(years):
            if y < 2008 and maturity == "long_term" and k == 0:
                continue  # March 2000 column is not an end-June observation
            rows.append(dict(vintage=2008, source_file=pdf, pdf_page=pg, table=anchor.split(".")[0], maturity=maturity,
                             year=y, total_foreign=tot[k], official=off[k], private="", pct_official_published=pct[k]))
    return rows


def exhibit2_2025():
    """2025 report Exhibit 2: all foreign-owned Treasury debt (long- and short-term)
    against total marketable Treasury debt outstanding at market value. A different
    denominator from the official/private split."""
    pdf = "shl2025r.pdf"
    pg = find_page(pdf, "Exhibit 2: Foreign Holdings of U.S. Securities by Type", start=5)
    lines = page_text(pdf, pg).splitlines()
    years = [int(y) for y in re.findall(r"\b(20\d\d)\b", next(l for l in lines if re.match(r"^20\d\d 20\d\d", l)))]
    i = next(k for k, l in enumerate(lines) if l.strip() == "Treasury debt" and k > 5)
    blk = {}
    for l in lines[i + 1 : i + 5]:
        for lab in ("Total U.S. securities", "U.S.-owned", "Foreign-owned", "Percent foreign-owned"):
            if l.startswith(lab):
                blk[lab] = nums(l[len(lab):])
    return [dict(vintage=2025, source_file=pdf, pdf_page=pg, table="Exhibit 2", year=y,
                 treasury_outstanding_mv=blk["Total U.S. securities"][k], us_owned=blk["U.S.-owned"][k],
                 foreign_owned=blk["Foreign-owned"][k], pct_foreign_owned_published=blk["Percent foreign-owned"][k])
            for k, y in enumerate(years)]


if __name__ == "__main__":
    write("vintage_2025.csv", recent_format("shl2025r.pdf", 2025,
          "Exhibit 7: U.S. Long-Term Securities by Foreign Holder Sector",
          "Exhibit 8: U.S. Short-Term Securities by Foreign Holder Sector"))
    write("vintage_2024.csv", recent_format("shl2024r.pdf", 2024,
          "Table 8: U.S. Long-Term Securities by Foreign Holder Sector",
          "Table 9: U.S. Short-Term Securities by Foreign Holder Sector"))
    write("vintage_2016.csv", v2016())
    write("vintage_2008.csv", v2008())
    write("exhibit2_2025_outstanding.csv", exhibit2_2025())
