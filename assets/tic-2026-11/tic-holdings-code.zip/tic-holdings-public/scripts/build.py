"""Build the analytical dataset from the verbatim extracts.

Primary series: the 2025 report (published April 2026), which gives one revised,
internally consistent 2008-2025 series. Earlier report vintages are used only in
validate.py, to measure revisions.

Output: data/treasury_official_private.csv (one row per survey year and maturity)
and data/treasury_outstanding_share.csv (the different, all-holders denominator).

Run: python3 scripts/build.py
"""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXT = ROOT / "data" / "extracts"

# Survey reference dates as listed on Treasury's SHL reports page. The 2024 report's own
# title says June 28, 2024 while the listing says 6/30/2024; documented in docs/methods.md.
SURVEY_DATE = {2018: "2018-06-29", 2019: "2019-06-28", 2024: "2024-06-28"}
BENCHMARK_YEARS = {2009, 2014, 2019, 2024}  # benchmark (SHL) years; others are annual (SHLA) surveys


def read(name):
    with (EXT / name).open() as f:
        return list(csv.DictReader(f))


def main():
    rows = read("vintage_2025.csv")
    by = {(int(r["year"]), r["maturity"]): r for r in rows}
    out = []
    for year in sorted({y for y, _ in by}):
        parts = {}
        for mat in ("long_term", "short_term"):
            r = by[(year, mat)]
            tot, off, prv = float(r["total_foreign"]), float(r["official"]), float(r["private"])
            parts[mat] = (tot, off, prv)
            out.append(dict(year=year, survey_date=SURVEY_DATE.get(year, f"{year}-06-30"),
                            survey_type="benchmark" if year in BENCHMARK_YEARS else "annual",
                            maturity=mat, total_foreign_bn=tot, official_bn=off, private_bn=prv,
                            official_share_pct=round(100 * off / tot, 2),
                            official_share_published_pct=float(r["pct_official_published"]),
                            source=f'{r["source_file"]} p.{r["pdf_page"]} ({r["table"].split(":")[0]})'))
        tot = sum(p[0] for p in parts.values())
        off = sum(p[1] for p in parts.values())
        prv = sum(p[2] for p in parts.values())
        out.append(dict(year=year, survey_date=SURVEY_DATE.get(year, f"{year}-06-30"),
                        survey_type="benchmark" if year in BENCHMARK_YEARS else "annual",
                        maturity="all", total_foreign_bn=tot, official_bn=off, private_bn=prv,
                        official_share_pct=round(100 * off / tot, 2), official_share_published_pct="",
                        source="derived: long_term + short_term (shl2025r.pdf Exhibits 7 and 8)"))
    path = ROOT / "data" / "treasury_official_private.csv"
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0]))
        w.writeheader()
        w.writerows(out)
    print(f"wrote {path.relative_to(ROOT)} ({len(out)} rows)")

    ex2 = read("exhibit2_2025_outstanding.csv")
    out2 = [dict(year=int(r["year"]), treasury_outstanding_mv_bn=float(r["treasury_outstanding_mv"]),
                 foreign_owned_bn=float(r["foreign_owned"]),
                 foreign_share_of_outstanding_pct=round(100 * float(r["foreign_owned"]) / float(r["treasury_outstanding_mv"]), 2),
                 foreign_share_published_pct=float(r["pct_foreign_owned_published"]),
                 source=f'{r["source_file"]} p.{r["pdf_page"]} (Exhibit 2)') for r in ex2]
    path = ROOT / "data" / "treasury_outstanding_share.csv"
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out2[0]))
        w.writeheader()
        w.writerows(out2)
    print(f"wrote {path.relative_to(ROOT)} ({len(out2)} rows)")


if __name__ == "__main__":
    main()
